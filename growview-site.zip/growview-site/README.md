# GrowView AI site

Static single-page site. No build step. React, Tailwind, Lucide and htm load from CDNs at runtime.

## Deploy to Vercel

Option 1, dashboard: go to vercel.com/new, choose "Import" or drag this folder in. Framework preset: Other. Leave build command and output directory empty.

Option 2, CLI, from this folder:

    npm i -g vercel
    vercel --prod

Then add `growview.app` under Project > Settings > Domains.

## Still to wire up

- The intake form only shows a copyable request. Point its submit handler at a real endpoint (a Vercel function, Formspree, etc.).
- The PDF export is a simulated preview. Swap in a real generator (for example jsPDF) when the scanner is live.
